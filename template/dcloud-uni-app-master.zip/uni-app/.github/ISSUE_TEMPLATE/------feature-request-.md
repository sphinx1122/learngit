---
name: 建议新功能（Feature Request）
about: 对 uni-app 提出改善建议
title: ''
labels: enhancement
assignees: ''

---

**新功能描述**
简洁描述你希望补充完善的增强功能

**现状及问题**
[当前现状及由此导致的不便]

**尝试方案**
[如果你有尝试绕开或其它解决方案，在这里描述你的建议方案]

**补充信息**
[其它你认为有参考价值的信息]
