# uni-one

> 使用uni-app开发的 [「ONE · 一个」](http://wufazhuce.com)  
> 移植自[mpvue-one](https://github.com/feng-fu/mpvue-one/blob/master/README.md)  
> 本项目仅作为mpvue项目移植示例  

## 使用方式
将项目拖入[HbuilderX](http://www.dcloud.io/hbuilderx.html),直接运行即可

## 注意事项
* 在小程序中预览提示合法域名校验出错，需打开微信开发者工具内 设置-项目设置，勾选“不校验合法域名、web-view（业务域名）、TLS 版本以及 HTTPS 证书”。