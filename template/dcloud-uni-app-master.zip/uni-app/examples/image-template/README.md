代码已迁移，请移步[https://github.com/dcloudio/uni-template-picture](https://github.com/dcloudio/uni-template-picture)查看最新代码
