<template>
	<view class="content">
		<navigator url="../vant/vant">
			<button type="default">vant组件示例</button>
		</navigator>
		<navigator url="../wux/wux">
			<button type="default">wux组件示例</button>
		</navigator>
	</view>
</template>

<script>
	export default {

	}
</script>

<style>
	button {
		margin-top: 20px;
	}
</style>
