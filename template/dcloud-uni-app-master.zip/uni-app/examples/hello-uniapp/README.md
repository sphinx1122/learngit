代码已迁移，请移步[https://github.com/dcloudio/hello-uniapp](https://github.com/dcloudio/hello-uniapp)查看最新代码
