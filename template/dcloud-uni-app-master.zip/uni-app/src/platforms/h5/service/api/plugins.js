export function getProvider ({
  service
}) {
  return {
    service,
    provider: []
  }
}
