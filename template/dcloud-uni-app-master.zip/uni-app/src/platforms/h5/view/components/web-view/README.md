# web-view
|属性|完成度|
|:-|:-|
|src|√|
|@message|-|

|方法|完成度|
|:-|:-|
|navigateTo|√|
|redirectTo|√|
|reLaunch|√|
|switchTab|√|
|navigateBack|√|
|getEnv|√|
|postMessage|-|
