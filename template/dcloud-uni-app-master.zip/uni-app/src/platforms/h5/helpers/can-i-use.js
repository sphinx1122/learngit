export default {
  'css.var': window.CSS && window.CSS.supports && window.CSS.supports('--a', 0)
}
