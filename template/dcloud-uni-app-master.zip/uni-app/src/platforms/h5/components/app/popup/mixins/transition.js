export default {
  methods: {
    beforeTransition () {},
    afterTransition () {}
  }
}
