export function requireNativePlugin (pluginName) {
  /* eslint-disable no-undef */
  return __requireNativePlugin__(pluginName)
}
