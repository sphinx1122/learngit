export const NAVBAR_HEIGHT = 44
export const TABBAR_HEIGHT = 50
