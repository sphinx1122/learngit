export const openDocument = {
  filePath: {
    type: String,
    required: true
  },
  fileType: {
    type: String
  }
}
