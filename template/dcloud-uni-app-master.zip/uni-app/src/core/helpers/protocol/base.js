export const canIUse = [{
  name: 'schema',
  type: String,
  required: true
}]
