module.exports = {
	ignore: [
		"./packages",
	],
	presets: [
		["@vue/app", {
			useBuiltIns: "entry"
		}]
	]
}
